package stepdefinitions;

import core.BaseTest;
import io.cucumber.java.en.*;
import pages.InventoryPage;
import pages.LoginPage;

import org.testng.Assert;
import org.openqa.selenium.WebDriver;
import java.util.*;

public class InventorySteps extends BaseTest {
    WebDriver driver;
    LoginPage loginPage;
    InventoryPage inventoryPage;

    @Given("User is logged in with {string} and {string}")
    public void user_is_logged_in_with_and(String username, String password) {
        driver = getDriver();
        loginPage = new LoginPage(driver);
        inventoryPage = new InventoryPage(driver);
        loginPage.login(username, password);
        Assert.assertTrue(inventoryPage.isInventoryPageDisplayed(), "Not displayed");
    }

    @Then("Inventory page title should be {string}")
    public void inventory_page_title_should_be(String title) {
        Assert.assertEquals(driver.getTitle(), title, "Page title not same");
    }

    @Then("Products should be visible")
    public void products_should_be_visible() {
        Assert.assertTrue(inventoryPage.isInventoryPageDisplayed(), "Not visible");
    }
    
    @Then("User should be redirected to login page")
    public void user_should_be_redirected_to_login_page() {
        Assert.assertTrue(driver.getCurrentUrl().contains("saucedemo.com"), "User not redirected to login page." + driver.getCurrentUrl());
    }

    @Then("Filter dropdown should be visible")
    public void filter_dropdown_should_be_visible() {
        Assert.assertTrue(inventoryPage.isFilterDropdownVisible(), "Filter not visible");
    }

    @Then("Filter dropdown should have options:")
    public void filter_dropdown_should_have_options(io.cucumber.datatable.DataTable dataTable) {
        List<String> expectedOptions = dataTable.asList();
        List<String> actualOptions = inventoryPage.getFilterOptions();
        Assert.assertEquals(actualOptions, expectedOptions, "Filter options not same");
    }

    @When("User selects {string} from filter dropdown")
    public void user_selects_from_filter_dropdown(String option) {
        inventoryPage.selectSortOption(option);
    }

    @Then("Products should be sorted in ascending order")
    public void products_should_be_sorted_in_ascending_order() {
        List<String> productNames = inventoryPage.getProductNames();
        List<String> sorted = new ArrayList<>(productNames);
        Collections.sort(sorted);
        Assert.assertEquals(productNames, sorted, "Products are not sorted");
    }

    @Then("Products should be sorted in descending order")
    public void products_should_be_sorted_in_descending_order() {
        List<String> productNames = inventoryPage.getProductNames();
        List<String> sorted = new ArrayList<>(productNames);
        sorted.sort(Collections.reverseOrder());
        Assert.assertEquals(productNames, sorted, "Products are not sorted");
    }

    @Then("Products should be sorted by increasing price")
    public void products_should_be_sorted_by_increasing_price() {
        List<Double> prices = inventoryPage.getProductPrices();
        List<Double> sorted = new ArrayList<>(prices);
        Collections.sort(sorted);
        Assert.assertEquals(prices, sorted, "Products not sorted");
    }

    @Then("Products should be sorted by decreasing price")
    public void products_should_be_sorted_by_decreasing_price() {
        List<Double> prices = inventoryPage.getProductPrices();
        List<Double> sorted = new ArrayList<>(prices);
        sorted.sort(Collections.reverseOrder());
        Assert.assertEquals(prices, sorted, "Products not sorted");
    }
}